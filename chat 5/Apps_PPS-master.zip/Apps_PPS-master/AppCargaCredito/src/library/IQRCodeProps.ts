export interface IQRCodeProps {
    name: string;
    number: string;
}